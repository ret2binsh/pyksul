while ($True){
    $programName = "msedge"
    $isRunning = (Get-Process -ea silentlycontinue $programName).count -gt 0
    if ($isRunning -eq $False)
    {([wmiclass]"win32_process").Create($programName)}
    Start-Sleep -seconds 2
}
